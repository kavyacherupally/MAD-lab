package com.example.loginform

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class HomePage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_page)
        val textV : TextView = findViewById(R.id.textV)
        val intent: Intent = intent
        val user=intent.getStringExtra("username")
        val pass=intent.getStringExtra("Password")
        textV.setText(user+" "+pass)
    }
}